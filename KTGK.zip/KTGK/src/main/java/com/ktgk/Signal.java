package com.example;

public abstract class Signal {
    // in kieu tin hieu
    public abstract void displaySignalType();
}